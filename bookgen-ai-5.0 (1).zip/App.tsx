import React, { useState, useEffect } from 'react';
import { IngestionStep } from './components/IngestionStep';
import { ConceptSelection } from './components/ConceptSelection';
import { ConfigurationStep } from './components/ConfigurationStep';
import { Reader } from './components/Reader';
import { LoginPage } from './components/LoginPage';
import { AppStep, BookConcept, BookConfiguration, GeneratedBook, ResearchSummary, UploadedFile } from './types';
import { analyzeAndResearch, generateBookContent } from './services/geminiService';
import { BookOpen, LogOut } from 'lucide-react';
import { supabase } from './services/supabaseClient';

const App: React.FC = () => {
  // Authentication State
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);
  const [isAuthChecking, setIsAuthChecking] = useState(true);

  // App Flow State
  const [step, setStep] = useState<AppStep>(AppStep.INGESTION);
  const [researchSummary, setResearchSummary] = useState<ResearchSummary | null>(null);
  const [concepts, setConcepts] = useState<BookConcept[]>([]);
  
  const [selectedConcept, setSelectedConcept] = useState<BookConcept | null>(null);
  const [selectedDeepDives, setSelectedDeepDives] = useState<string[]>([]);
  const [generatedBook, setGeneratedBook] = useState<GeneratedBook | null>(null);
  
  // Loading states
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [progressMsg, setProgressMsg] = useState('');
  const [progressPercent, setProgressPercent] = useState(0);

  // Check auth on mount
  useEffect(() => {
    checkAuth();
  }, []);

  const checkAuth = async () => {
    const auth = localStorage.getItem('bookgen_auth');
    if (auth === 'true') {
       // Check supabase session validity in a real app, assuming valid for demo continuity
       setIsAuthenticated(true);
    }
    setIsAuthChecking(false);
  };

  const handleLogin = async () => {
    localStorage.setItem('bookgen_auth', 'true');
    setIsAuthenticated(true);
  };

  const handleLogout = async () => {
    await supabase.auth.signOut();
    localStorage.removeItem('bookgen_auth');
    setIsAuthenticated(false);
    reset(); 
  };

  const handleAnalyze = async (text: string, files: UploadedFile[]) => {
    setIsAnalyzing(true);
    setStep(AppStep.RESEARCHING);
    try {
      // Use configured process.env.API_KEY in service
      const result = await analyzeAndResearch(text, files);
      setResearchSummary(result.summary);
      setConcepts(result.concepts);
      setStep(AppStep.CONCEPT_SELECTION);
    } catch (error: any) {
      console.error(error);
      alert(`Analysis failed: ${error.message || "Please check your network or API key settings."}`);
      setStep(AppStep.INGESTION);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleConceptSelect = (concept: BookConcept, selectedTopics: string[]) => {
    setSelectedConcept(concept);
    setSelectedDeepDives(selectedTopics);
    setStep(AppStep.CONFIGURATION);
  };

  const handleGenerate = async (config: BookConfiguration) => {
    setStep(AppStep.GENERATING);
    setProgressPercent(0);
    try {
      setProgressMsg("Preparing Book Structure...");
      setProgressPercent(2);
      
      const book = await generateBookContent(
        config.selectedConcept, 
        config.outline, 
        config.pageCount,
        config.tone,
        config.style,
        config.isAutoStyle,
        config.additionalTopics,
        config.authorConfig,
        (msg, percent) => {
          setProgressMsg(msg);
          setProgressPercent(percent);
        }
      );
      
      setGeneratedBook(book);
      setStep(AppStep.COMPLETED);
    } catch (error: any) {
      console.error(error);
      alert(`Generation failed: ${error.message}`);
      setStep(AppStep.CONFIGURATION);
    }
  };

  const reset = () => {
    setStep(AppStep.INGESTION);
    setResearchSummary(null);
    setConcepts([]);
    setSelectedConcept(null);
    setSelectedDeepDives([]);
    setGeneratedBook(null);
    setProgressPercent(0);
  };

  // Render Login Page if not authenticated
  if (isAuthChecking) return null; // Or a spinner
  
  if (!isAuthenticated) {
    return <LoginPage onLogin={handleLogin} />;
  }

  return (
    <div className="min-h-screen bg-white text-black font-sans relative">

      {/* Background decoration */}
      <div className="fixed inset-0 z-0 pointer-events-none opacity-30">
        <div className="absolute -top-[20%] -left-[10%] w-[50%] h-[50%] bg-blue-50 rounded-full blur-3xl"></div>
        <div className="absolute top-[40%] right-0 w-[40%] h-[40%] bg-slate-100 rounded-full blur-3xl"></div>
      </div>

      {/* Navigation Buttons - Responsive Positioning */}
      <div className="absolute top-4 right-4 md:top-6 md:right-6 z-50 flex items-center gap-2 md:gap-3">
        <button 
          onClick={handleLogout}
          className="text-xs font-bold text-slate-400 hover:text-red-500 flex items-center gap-2 transition-colors px-2 py-1.5 md:px-3 md:py-2 rounded-lg hover:bg-red-50"
        >
          <LogOut className="w-3 h-3" /> 
          <span className="hidden sm:inline">Sign Out</span>
        </button>
      </div>

      <div className="relative z-10">
        {step === AppStep.INGESTION && (
          <IngestionStep onAnalyze={handleAnalyze} isAnalyzing={isAnalyzing} />
        )}

        {step === AppStep.RESEARCHING && (
           <div className="flex flex-col items-center justify-center min-h-screen bg-white px-6 text-center">
             <div className="w-16 h-16 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mb-6"></div>
             <h2 className="text-xl md:text-2xl font-bold text-black animate-pulse">Conducting Deep Research...</h2>
             <p className="text-gray-500 mt-2 text-sm md:text-base">Analyzing content, adopting expert personas, and formulating insights.</p>
           </div>
        )}

        {step === AppStep.CONCEPT_SELECTION && researchSummary && (
          <ConceptSelection 
            summary={researchSummary} 
            concepts={concepts} 
            onSelect={handleConceptSelect} 
          />
        )}

        {step === AppStep.CONFIGURATION && selectedConcept && (
          <ConfigurationStep 
            concept={selectedConcept}
            additionalTopics={selectedDeepDives}
            onGenerate={handleGenerate} 
          />
        )}

        {step === AppStep.GENERATING && (
          <div className="flex flex-col items-center justify-center min-h-screen p-8 text-center bg-white">
            <BookOpen className="w-16 h-16 md:w-20 md:h-20 text-blue-600 mb-8 animate-bounce" />
            
            <div className="w-full max-w-md space-y-4">
              <div className="flex justify-between items-end">
                 <h2 className="text-lg md:text-xl font-bold text-black">{progressMsg}</h2>
                 <span className="text-sm font-bold text-blue-600">{progressPercent}%</span>
              </div>
              
              <div className="w-full bg-slate-100 rounded-full h-4 overflow-hidden shadow-inner">
                <div 
                  className="bg-blue-600 h-full rounded-full transition-all duration-500 ease-out"
                  style={{ width: `${progressPercent}%` }}
                ></div>
              </div>
              
              <p className="text-gray-500 text-xs md:text-sm">
                Writing a professional book requires precision. If the AI is busy, we will automatically retry.
              </p>
            </div>
          </div>
        )}

        {step === AppStep.COMPLETED && generatedBook && (
          <Reader book={generatedBook} onReset={reset} />
        )}
      </div>
    </div>
  );
};

export default App;