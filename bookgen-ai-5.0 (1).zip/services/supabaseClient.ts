import { createClient } from '@supabase/supabase-js';

// Configuration
// In Vite, we use import.meta.env.VITE_* for client-side environment variables.
// Casting import.meta to any to avoid TypeScript errors if vite/client types are missing
const env = (import.meta as any).env;

const supabaseUrl = env?.VITE_SUPABASE_URL || 'https://tysbirsqrxpgtdpipjhp.supabase.co';
const supabaseAnonKey = env?.VITE_SUPABASE_ANON_KEY || 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InR5c2JpcnNxcnhwZ3RkcGlwamhwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Njg5OTg4NDMsImV4cCI6MjA4NDU3NDg0M30.5HM9555cihT_lMCewvAoGpngqVFrnzKBBWU-SU-sKFA';

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

// Helper to check if we are in "Real Database" mode or "Demo" mode
export const isSupabaseConfigured = () => true;