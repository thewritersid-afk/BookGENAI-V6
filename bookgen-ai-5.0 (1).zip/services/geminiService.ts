import { GoogleGenAI } from "@google/genai";
import { BookConcept, GeneratedBook, ResearchSummary, UploadedFile, Chapter, StyleConfig, BookThemeId, AuthorConfig } from "../types";

// Update: Use process.env.API_KEY directly as per guidelines
const getAI = () => {
  // The API key must be obtained exclusively from the environment variable process.env.API_KEY.
  return new GoogleGenAI({ apiKey: process.env.API_KEY });
};

// Helper to clean JSON string
const cleanJson = (text: string) => {
  return text.replace(/```json/g, '').replace(/```/g, '').trim();
};

// Retry wrapper for 429 errors
async function retryWithBackoff<T>(fn: () => Promise<T>, retries = 3, delay = 2000): Promise<T> {
  try {
    return await fn();
  } catch (error: any) {
    if (retries > 0 && (error.status === 429 || error.code === 429 || error.message?.includes('429') || error.message?.includes('RESOURCE_EXHAUSTED'))) {
      console.warn(`Quota exceeded (429). Retrying in ${delay}ms...`);
      await new Promise(resolve => setTimeout(resolve, delay));
      return retryWithBackoff(fn, retries - 1, delay * 2);
    }
    throw error;
  }
}

const THEMES: Record<BookThemeId, StyleConfig> = {
  Modern: { themeId: 'Modern', fontHeader: 'font-sans', fontBody: 'font-sans', density: 'comfortable' },
  Classic: { themeId: 'Classic', fontHeader: 'font-playfair', fontBody: 'font-serif', density: 'comfortable' },
  Academic: { themeId: 'Academic', fontHeader: 'font-sans', fontBody: 'font-lora', density: 'compact' },
  Minimal: { themeId: 'Minimal', fontHeader: 'font-sans', fontBody: 'font-mono-custom', density: 'spacious' },
};

export const analyzeAndResearch = async (
  input: string, 
  files: UploadedFile[]
): Promise<{ summary: ResearchSummary; concepts: BookConcept[] }> => {
  const ai = getAI();
  
  const fileParts = files.map(f => ({
    inlineData: {
      mimeType: f.mimeType,
      data: f.data
    }
  }));

  const prompt = `
    You are an elite Lead Researcher and Editor-in-Chief with 20 years of experience in academic and commercial publishing.
    
    Step 1: Conduct a rigorous analysis of the provided content (text and files). 
    Step 2: Synthesize a "Content Overview" summarizing the narrative flow and main ideas.
    Step 3: Extract the "Central Arguments" (the core theses being presented) and determine the "Overall Sentiment" (e.g., Optimistic, Critical, Analytical, Urgent).
    Step 4: Identify "Key Topics" present in the text.
    Step 5: Propose "Suggested Deep Dive Topics" - these should be 3-5 related areas, historical contexts, or future implications that are NOT heavily detailed in the source but would add significant depth and value to a full-length book.
    Step 6: Adopt a specific "Expert Persona" best suited to write this book.
    Step 7: Propose 3 distinct, high-potential book concepts.

    Return the result as JSON matching this schema:
    {
      "summary": {
        "contentOverview": "string",
        "keyTopics": ["string"],
        "centralArguments": ["string"],
        "sentiment": "string",
        "suggestedDeepDiveTopics": ["string"],
        "insight": "string",
        "expertPersona": "string"
      },
      "concepts": [
        {
          "id": "1",
          "title": "string",
          "subtitle": "string",
          "description": "string",
          "targetAudience": "string",
          "estimatedChapters": number
        }
      ]
    }
  `;

  return retryWithBackoff(async () => {
    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: {
        parts: [
          ...fileParts,
          { text: input ? `Additional Context/Script: ${input}` : '' },
          { text: prompt }
        ]
      },
      config: {
        responseMimeType: 'application/json',
        tools: [{ googleSearch: {} }]
      }
    });

    // Extract grounding sources
    const sources: string[] = [];
    const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks;
    if (chunks) {
      chunks.forEach((chunk: any) => {
        if (chunk.web?.uri) {
           sources.push(chunk.web.uri);
        }
      });
    }
    const uniqueSources = Array.from(new Set(sources));

    try {
      const parsed = JSON.parse(cleanJson(response.text || '{}'));
      if (parsed.summary) {
        parsed.summary.sources = uniqueSources;
      }
      return parsed;
    } catch (e) {
      console.error("Failed to parse analysis", e);
      throw new Error("Could not analyze content. Please try again.");
    }
  });
};

export const generateOutline = async (concept: BookConcept, pageCount: number, targetChapters: number, additionalTopics: string[]): Promise<string[]> => {
  const ai = getAI();
  
  const prompt = `
    Based on the book concept:
    Title: ${concept.title}
    Subtitle: ${concept.subtitle}
    Description: ${concept.description}
    Target Length: ${pageCount} pages.
    Structure: Exactly ${targetChapters} chapters.

    The user has also requested to incorporate these specific Deep Dive Topics into the book's scope:
    ${additionalTopics.join(', ')}

    Generate a comprehensive Table of Contents with exactly ${targetChapters} chapters.
    Ensure the additional topics are logically integrated into the chapter flow.
    Return ONLY a JSON array of strings, where each string is a chapter title.
    
    Example: ["Chapter 1: The Beginning", "Chapter 2: Middle", ...]
  `;

  return retryWithBackoff(async () => {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        responseMimeType: 'application/json'
      }
    });

    try {
      return JSON.parse(cleanJson(response.text || '[]'));
    } catch (e) {
      throw new Error("Failed to generate outline.");
    }
  });
};

const KDP_RULES = `
  📕 BOOKGEN AI — MASTER KDP FORMATTING RULES
  1. CONTENT INTEGRITY: Do NOT summarize. Write full, deep content. Do NOT delete sentences. Preserve wording.
  2. STRUCTURE: No bullet points unless absolutely necessary. Format as continuous, flowing book prose.
  3. SPACING: Ensure long paragraphs. No short, choppy sentences.
  4. FLOW: Every line must span the full width of the intellectual argument. No broken phrases.
  5. OUTPUT: Markdown format. Headings with ##. No special characters that break PDF rendering.
`;

export const generateBookContent = async (
  concept: BookConcept, 
  outline: string[], 
  pageCount: number,
  tone: string,
  stylePreference: StyleConfig,
  isAutoStyle: boolean,
  additionalTopics: string[],
  authorConfig: AuthorConfig,
  onProgress: (msg: string, percent: number) => void
): Promise<GeneratedBook> => {
  const ai = getAI();
  const chapters: Chapter[] = [];
  
  const totalSteps = outline.length + 3; // Author + Intro + Chapters + Conclusion
  let currentStep = 0;

  const updateProgress = (msg: string) => {
    currentStep++;
    const percent = Math.round((currentStep / totalSteps) * 100);
    onProgress(msg, percent);
  };

  const finalStyle = isAutoStyle ? THEMES.Classic : stylePreference;

  // 1. Author Persona Generation (Conditional)
  let authorData = { name: "BookGen AI", bio: "" };
  
  if (authorConfig.includeProfile) {
    if (authorConfig.isAiGenerated) {
       updateProgress("Creating Author Persona...");
       const authorPrompt = `
         Create a credible, expert author persona for a book titled "${concept.title}".
         Target Audience: ${concept.targetAudience}.
         Topic: ${concept.description}.
         Incorporated Research Areas: ${additionalTopics.join(', ')}.
         Tone: ${tone}.
         
         Return ONLY a JSON object with this schema:
         {
           "name": "string",
           "bio": "string (A compelling 80-120 word biography)"
         }
       `;

       authorData = await retryWithBackoff(async () => {
         const authorResp = await ai.models.generateContent({
           model: 'gemini-3-flash-preview',
           contents: authorPrompt,
           config: { responseMimeType: 'application/json' }
         });
         try {
           return JSON.parse(cleanJson(authorResp.text || '{}'));
         } catch(e) {
           return { name: "BookGen AI", bio: "An AI-powered expert system." };
         }
       });
    } else {
       // Manual Input
       updateProgress("Processing Author Profile...");
       authorData = {
         name: authorConfig.name || "Unknown Author",
         bio: authorConfig.bio || ""
       };
       // Fast track progress since no API call
       await new Promise(r => setTimeout(r, 500));
    }
  } else {
    // No profile included, but we might have a name override for the cover
    authorData = {
      name: authorConfig.name || "BookGen AI",
      bio: "" // Empty bio triggers "No Author Page" logic in Reader
    };
    updateProgress("Skipping Author Persona...");
  }

  // 2. Intro
  updateProgress("Drafting Introduction...");
  const introPrompt = `
    ${KDP_RULES}
    Write a compelling Introduction for the book "${concept.title}".
    Tone: ${tone}.
    Context: ${concept.description}.
    Target Length: ${pageCount} pages total. This intro should set the stage.
    Deep Dive Research Topics to Mention: ${additionalTopics.join(', ')}.
    Outline: ${JSON.stringify(outline)}.
    
    STRICT OUTPUT RULES:
    1. Return ONLY the content in Markdown.
    2. Ensure paragraphs are long, detailed, and separated by blank lines (for processing).
    3. Use bold (##) for headings.
  `;
  
  const introduction = await retryWithBackoff(async () => {
    const introResp = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: introPrompt
    });
    return introResp.text || "";
  });

  // 3. Chapters
  for (let i = 0; i < outline.length; i++) {
    const chapterTitle = outline[i];
    updateProgress(`Researching & Writing ${chapterTitle}...`);
    
    // Calculate relative depth based on total page count
    // A 300 page book with 15 chapters needs ~20 pages per chapter.
    // A 10 page book with 3 chapters needs ~3 pages per chapter.
    const depthInstruction = `
      This book is intended to be ${pageCount} pages long in total. 
      There are ${outline.length} chapters.
      Please ensure this chapter is sufficiently detailed to meet this length requirement. 
      Expand on concepts, provide examples, historical context, and deep analysis.
    `;

    const chapterPrompt = `
      ${KDP_RULES}
      Write the full content for ${chapterTitle} of the book "${concept.title}".
      ${depthInstruction}
      Tone: ${tone}.
      Context: ${concept.description}.
      Additional Research Themes: ${additionalTopics.join(', ')}.
      Previous Chapter context: ${i > 0 ? outline[i-1] : 'None'}.
      
      STRICT OUTPUT RULES:
      1. Return ONLY the actual chapter content. 
      2. Do NOT include any conversational filler.
      3. Use Markdown formatting. 
      4. Use bold (## or ###) for subheadings.
      5. Ensure paragraphs are long, detailed.
      6. FORMATTING: Ensure no words are concatenated. Double-check all spacing between words and sentences.
    `;

    const content = await retryWithBackoff(async () => {
      const result = await ai.models.generateContent({
        model: 'gemini-3-pro-preview',
        contents: chapterPrompt
      });
      return result.text || "";
    });

    chapters.push({
      number: i + 1,
      title: chapterTitle,
      content
    });
  }

  // 4. Conclusion
  updateProgress("Finalizing Conclusion...");
  const conclusionPrompt = `
    ${KDP_RULES}
    Write a powerful Conclusion for the book "${concept.title}".
    Summarize key takeaways from these chapters: ${JSON.stringify(outline)}.
    Synthesize the additional research themes: ${additionalTopics.join(', ')}.
    Provide a call to action or final thought.
    Tone: ${tone}.
    Use Markdown.
    FORMATTING: Ensure clean spacing and paragraph breaks.
  `;
  
  const conclusion = await retryWithBackoff(async () => {
    const concResp = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: conclusionPrompt
    });
    return concResp.text || "";
  });

  return {
    title: concept.title,
    subtitle: concept.subtitle,
    author: authorData.name,
    authorBio: authorData.bio,
    introduction,
    chapters,
    conclusion,
    styleConfig: finalStyle
  };
};