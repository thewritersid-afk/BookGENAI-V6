
export enum AppStep {
  INGESTION = 'INGESTION',
  RESEARCHING = 'RESEARCHING',
  CONCEPT_SELECTION = 'CONCEPT_SELECTION',
  CONFIGURATION = 'CONFIGURATION',
  GENERATING = 'GENERATING',
  COMPLETED = 'COMPLETED',
}

export interface UploadedFile {
  name: string;
  type: string;
  data: string; // Base64
  mimeType: string;
}

export interface BookConcept {
  id: string;
  title: string;
  subtitle: string;
  description: string;
  targetAudience: string;
  estimatedChapters: number;
}

export type BookThemeId = 'Modern' | 'Classic' | 'Academic' | 'Minimal';

export interface StyleConfig {
  themeId: BookThemeId;
  fontHeader: string; // CSS class for font family
  fontBody: string;   // CSS class for font family
  density: 'compact' | 'comfortable' | 'spacious';
}

export interface AuthorConfig {
  includeProfile: boolean; // Whether to include "About the Author" page
  isAiGenerated: boolean; // Whether to let AI invent the persona
  name?: string;          // Manual override or cover name
  bio?: string;           // Manual override for bio
}

export interface BookConfiguration {
  selectedConcept: BookConcept;
  pageCount: number; // Target number of pages (10-300)
  outline: string[]; // The generated list of chapters
  tone: 'Professional' | 'Casual' | 'Academic' | 'Storytelling';
  style: StyleConfig;
  isAutoStyle: boolean;
  additionalTopics: string[];
  authorConfig: AuthorConfig;
}

export interface Chapter {
  number: number;
  title: string;
  content: string; // Markdown or HTML
}

export interface GeneratedBook {
  title: string;
  subtitle: string;
  author: string;
  authorBio: string;
  introduction: string;
  chapters: Chapter[];
  conclusion: string;
  styleConfig: StyleConfig;
}

export interface ResearchSummary {
  contentOverview: string;
  keyTopics: string[];
  centralArguments: string[];
  sentiment: string;
  suggestedDeepDiveTopics: string[];
  insight: string;
  expertPersona: string;
  sources?: string[];
}

// Global declaration for jsPDF
declare global {
  interface Window {
    jspdf: any;
    html2canvas: any;
  }
}