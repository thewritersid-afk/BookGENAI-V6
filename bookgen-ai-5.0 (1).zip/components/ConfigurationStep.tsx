import React, { useState, useEffect } from 'react';
import { BookConcept, BookConfiguration, StyleConfig, BookThemeId, AuthorConfig } from '../types';
import { generateOutline } from '../services/geminiService';
import { Settings, PenTool, BookOpen, Palette, Layout, Wand2, Sparkles, Layers, List, Play, RotateCcw, UserCircle, UserPen, Type } from 'lucide-react';

interface Props {
  concept: BookConcept;
  additionalTopics: string[];
  onGenerate: (config: BookConfiguration) => void;
}

const THEMES: Record<BookThemeId, StyleConfig> = {
  Modern: { themeId: 'Modern', fontHeader: 'font-sans', fontBody: 'font-sans', density: 'comfortable' },
  Classic: { themeId: 'Classic', fontHeader: 'font-playfair', fontBody: 'font-serif', density: 'comfortable' },
  Academic: { themeId: 'Academic', fontHeader: 'font-sans', fontBody: 'font-lora', density: 'compact' },
  Minimal: { themeId: 'Minimal', fontHeader: 'font-sans', fontBody: 'font-mono-custom', density: 'spacious' },
};

export const ConfigurationStep: React.FC<Props> = ({ concept, additionalTopics, onGenerate }) => {
  // Page count now drives the logic. Default to 50 pages.
  const [pageCount, setPageCount] = useState(50);
  const [tone, setTone] = useState<BookConfiguration['tone']>('Professional');
  
  // Outline State
  const [outline, setOutline] = useState<string[]>([]);
  const [isGeneratingOutline, setIsGeneratingOutline] = useState(false);
  const [chapterCount, setChapterCount] = useState<number>(concept.estimatedChapters || 10);
  
  // Author State
  const [includeAuthorProfile, setIncludeAuthorProfile] = useState(true);
  const [isAiAuthor, setIsAiAuthor] = useState(true);
  const [authorName, setAuthorName] = useState('');
  const [authorBio, setAuthorBio] = useState('');

  // Style State
  const [isAutoStyle, setIsAutoStyle] = useState(true);
  const [selectedTheme, setSelectedTheme] = useState<BookThemeId>('Modern');
  const [customStyle, setCustomStyle] = useState<StyleConfig>(THEMES['Modern']);

  // Update custom style when theme changes
  useEffect(() => {
    if (!isAutoStyle) {
      setCustomStyle(THEMES[selectedTheme]);
    }
  }, [selectedTheme, isAutoStyle]);

  const handleGenerateOutline = async () => {
    setIsGeneratingOutline(true);
    try {
      const generatedOutline = await generateOutline(concept, pageCount, chapterCount, additionalTopics);
      setOutline(generatedOutline);
    } catch (error) {
      alert("Failed to generate outline. Please check your API key environment configuration.");
    } finally {
      setIsGeneratingOutline(false);
    }
  };

  const handleGenerateClick = () => {
    if (outline.length === 0) {
      alert("Please generate an outline first!");
      return;
    }

    const authorConfig: AuthorConfig = {
      includeProfile: includeAuthorProfile,
      isAiGenerated: isAiAuthor,
      name: authorName,
      bio: authorBio
    };

    onGenerate({ 
      selectedConcept: concept, 
      pageCount,
      outline,
      tone,
      style: customStyle,
      isAutoStyle,
      additionalTopics,
      authorConfig
    });
  };

  return (
    <div className="max-w-6xl mx-auto p-6 animate-fade-in">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        
        {/* Structure & Content Column */}
        <div className="bg-white rounded-3xl shadow-xl overflow-hidden border border-slate-100 h-full flex flex-col">
          <div className="bg-slate-900 p-6 text-white">
            <h2 className="text-xl font-bold flex items-center gap-2"><Settings className="w-5 h-5" /> Structure & Outline</h2>
          </div>
          <div className="p-6 space-y-8 flex-grow">
            
            {/* Page Count Slider */}
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <label className="font-bold text-slate-700 text-sm flex items-center gap-2">
                  <BookOpen className="w-4 h-4 text-blue-500" /> Target Length
                </label>
                <span className="bg-blue-50 text-blue-700 px-3 py-1 rounded-full text-xs font-bold">
                  {pageCount} Pages
                </span>
              </div>
              <input 
                type="range" 
                min="10" 
                max="300" 
                step="10"
                value={pageCount} 
                onChange={(e) => {
                  setPageCount(parseInt(e.target.value));
                }}
                className="w-full h-2 bg-slate-100 rounded-lg appearance-none cursor-pointer accent-blue-600"
              />
              <div className="flex justify-between text-[10px] uppercase font-bold text-slate-400">
                <span>Booklet (10)</span>
                <span>Standard (150)</span>
                <span>Novel (300)</span>
              </div>
            </div>

            {/* Tone Selection */}
            <div className="space-y-4">
              <label className="font-bold text-slate-700 text-sm flex items-center gap-2">
                <PenTool className="w-4 h-4 text-purple-500" /> Narrative Tone
              </label>
              <div className="grid grid-cols-2 gap-3">
                {['Professional', 'Casual', 'Academic', 'Storytelling'].map((t) => (
                  <button 
                    key={t}
                    onClick={() => setTone(t as any)}
                    className={`
                      p-3 rounded-lg text-sm transition-all text-center border font-medium
                      ${tone === t 
                        ? 'border-blue-500 bg-blue-50 text-blue-700 shadow-sm ring-1 ring-blue-500' 
                        : 'border-slate-200 hover:border-blue-300 text-slate-600'}
                    `}
                  >
                    {t}
                  </button>
                ))}
              </div>
            </div>

            {/* Author Configuration */}
            <div className="space-y-4 pt-4 border-t border-slate-100">
              <div className="flex items-center justify-between">
                <label className="font-bold text-slate-700 text-sm flex items-center gap-2">
                  <UserCircle className="w-4 h-4 text-green-600" /> Author Profile
                </label>
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-bold uppercase text-slate-400">
                    {includeAuthorProfile ? 'Include' : 'Skip'}
                  </span>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input 
                      type="checkbox" 
                      className="sr-only peer" 
                      checked={includeAuthorProfile} 
                      onChange={() => setIncludeAuthorProfile(!includeAuthorProfile)} 
                    />
                    <div className="w-9 h-5 bg-slate-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-green-600"></div>
                  </label>
                </div>
              </div>

              {includeAuthorProfile ? (
                <div className="bg-slate-50 rounded-xl p-4 border border-slate-200 space-y-4 animate-fade-in">
                  
                  {/* AI Author Toggle */}
                  <div className="flex items-center justify-between pb-3 border-b border-slate-200">
                    <div className="flex items-center gap-2">
                      <Wand2 className="w-4 h-4 text-purple-500" />
                      <span className="text-sm font-semibold text-slate-700">AI Author Creator</span>
                    </div>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input 
                        type="checkbox" 
                        className="sr-only peer" 
                        checked={isAiAuthor} 
                        onChange={() => setIsAiAuthor(!isAiAuthor)} 
                      />
                      <div className="w-9 h-5 bg-slate-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-purple-600"></div>
                    </label>
                  </div>

                  {isAiAuthor ? (
                     <div className="flex gap-3 text-xs text-slate-500 italic">
                        <Sparkles className="w-4 h-4 text-purple-400 flex-shrink-0" />
                        We will generate a credible expert persona tailored to this specific book concept.
                     </div>
                  ) : (
                    <div className="space-y-3 animate-fade-in">
                      <div>
                        <label className="block text-xs font-bold text-slate-500 mb-1">Author Name</label>
                        <input 
                          type="text" 
                          value={authorName}
                          onChange={(e) => setAuthorName(e.target.value)}
                          placeholder="e.g. Dr. John Smith"
                          className="w-full text-sm p-2 rounded-lg border border-slate-300 bg-white text-slate-900 focus:ring-2 focus:ring-purple-500 outline-none"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-bold text-slate-500 mb-1">About the Author (Max 3000 chars)</label>
                        <textarea 
                          value={authorBio}
                          onChange={(e) => setAuthorBio(e.target.value)}
                          maxLength={3000}
                          placeholder="Write a brief biography..."
                          className="w-full text-sm p-2 rounded-lg border border-slate-300 bg-white text-slate-900 focus:ring-2 focus:ring-purple-500 outline-none min-h-[100px]"
                        />
                        <div className="text-[10px] text-right text-slate-400 mt-1">
                          {authorBio.length}/3000
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              ) : (
                <div className="bg-slate-50 rounded-xl p-4 border border-slate-200 space-y-3 opacity-80">
                   <div className="flex gap-3 text-xs text-slate-500">
                      <UserPen className="w-4 h-4 text-slate-400 flex-shrink-0" />
                      The "About the Author" page will be excluded from the generated book.
                   </div>
                   <div>
                      <label className="block text-xs font-bold text-slate-500 mb-1">Author Name (For Cover)</label>
                      <input 
                        type="text" 
                        value={authorName}
                        onChange={(e) => setAuthorName(e.target.value)}
                        placeholder="e.g. BookGen AI (Default)"
                        className="w-full text-sm p-2 rounded-lg border border-slate-300 bg-white text-slate-900 focus:ring-2 focus:ring-slate-500 outline-none"
                      />
                   </div>
                </div>
              )}
            </div>

            {/* Outline Generation / Preview */}
            <div className="pt-4 border-t border-slate-100">
               <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-4">
                    <label className="font-bold text-slate-700 text-sm flex items-center gap-2">
                      <List className="w-4 h-4 text-slate-500" /> Chapter Outline
                    </label>
                    
                    <div className="flex items-center gap-2 bg-slate-50 border border-slate-200 rounded-lg px-2 py-1 shadow-sm group hover:border-blue-300 transition-colors">
                       <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider group-hover:text-blue-500">Chapters:</span>
                       <input 
                         type="number" 
                         min="3" 
                         max="50" 
                         value={chapterCount}
                         onChange={(e) => setChapterCount(Math.max(1, parseInt(e.target.value) || 0))}
                         className="w-10 text-xs font-bold text-slate-700 outline-none bg-transparent text-center focus:text-blue-600"
                       />
                    </div>
                  </div>
                  
                  <button 
                    onClick={handleGenerateOutline}
                    disabled={isGeneratingOutline}
                    className="text-xs bg-slate-100 hover:bg-slate-200 text-slate-700 px-3 py-1.5 rounded-lg font-bold flex items-center gap-1 transition-colors"
                  >
                     {isGeneratingOutline ? <RotateCcw className="w-3 h-3 animate-spin" /> : <Sparkles className="w-3 h-3 text-blue-500" />}
                     {outline.length > 0 ? "Regenerate" : "Generate"}
                  </button>
               </div>

               {isGeneratingOutline ? (
                 <div className="h-48 flex flex-col items-center justify-center text-slate-400 bg-slate-50 rounded-xl border border-dashed border-slate-200">
                    <div className="w-8 h-8 border-4 border-blue-500 border-t-transparent rounded-full animate-spin mb-3"></div>
                    <p className="text-sm font-medium">Planning {chapterCount} chapters...</p>
                 </div>
               ) : outline.length > 0 ? (
                 <div className="bg-slate-50 rounded-xl border border-slate-200 p-4 max-h-[300px] overflow-y-auto custom-scrollbar">
                    <ul className="space-y-2">
                      {outline.map((chapter, i) => (
                        <li key={i} className="text-sm text-slate-700 flex gap-3 p-2 bg-white rounded border border-slate-100 shadow-sm">
                           <span className="font-bold text-blue-500 min-w-[24px]">{(i+1).toString().padStart(2, '0')}</span>
                           <span>{chapter}</span>
                        </li>
                      ))}
                    </ul>
                 </div>
               ) : (
                 <div className="h-48 flex flex-col items-center justify-center text-slate-400 bg-slate-50 rounded-xl border border-dashed border-slate-200">
                    <List className="w-8 h-8 mb-2 opacity-50" />
                    <p className="text-sm">Click "Generate" to see chapters</p>
                 </div>
               )}
            </div>

          </div>
        </div>

        {/* Design & Style Column */}
        <div className="bg-white rounded-3xl shadow-xl overflow-hidden border border-slate-100 h-full flex flex-col">
          <div className="bg-blue-600 p-6 text-white">
            <h2 className="text-xl font-bold flex items-center gap-2"><Palette className="w-5 h-5" /> Design & Style</h2>
          </div>
          <div className="p-6 space-y-6 flex-grow">
            
            {/* Auto Toggle */}
            <div className="flex items-center justify-between p-4 bg-slate-50 rounded-xl border border-slate-200">
              <div className="flex items-center gap-3">
                <div className="bg-white p-2 rounded-lg shadow-sm text-blue-600">
                  <Wand2 className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-slate-900 text-sm">AI Auto-Design</h3>
                  <p className="text-xs text-slate-500">Let AI choose the best format</p>
                </div>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input type="checkbox" className="sr-only peer" checked={isAutoStyle} onChange={() => setIsAutoStyle(!isAutoStyle)} />
                <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
              </label>
            </div>

            {/* Manual Selection */}
            {!isAutoStyle && (
              <div className="space-y-6 animate-fade-in">
                <div className="space-y-3">
                  <label className="font-bold text-slate-700 text-sm">Visual Theme</label>
                  <div className="grid grid-cols-2 gap-3">
                    {Object.keys(THEMES).map((theme) => (
                      <button
                        key={theme}
                        onClick={() => setSelectedTheme(theme as BookThemeId)}
                        className={`
                          relative p-3 rounded-lg border text-left transition-all
                          ${selectedTheme === theme 
                            ? 'border-blue-500 ring-1 ring-blue-500 bg-blue-50' 
                            : 'border-slate-200 hover:border-blue-300'}
                        `}
                      >
                        <span className={`block text-sm font-bold mb-1 ${selectedTheme === theme ? 'text-blue-900' : 'text-slate-700'}`}>{theme}</span>
                        <span className="text-[10px] text-slate-500 block">
                          {theme === 'Modern' && 'Clean Sans-Serif'}
                          {theme === 'Classic' && 'Elegant Serif'}
                          {theme === 'Academic' && 'Dense & Formal'}
                          {theme === 'Minimal' && 'Airy & Monospace'}
                        </span>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Fine Tuning */}
                <div className="pt-4 border-t border-slate-100 space-y-4">
                  <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest">Fine Tuning</h4>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-semibold text-slate-600 mb-2">Heading Font</label>
                      <select 
                        value={customStyle.fontHeader}
                        onChange={(e) => setCustomStyle({...customStyle, fontHeader: e.target.value})}
                        className="w-full text-sm border-slate-200 rounded-lg p-2 bg-slate-50 focus:ring-2 focus:ring-blue-500 focus:outline-none"
                      >
                        <option value="font-sans">Modern Sans</option>
                        <option value="font-playfair">Playfair Display</option>
                        <option value="font-serif">Merriweather</option>
                        <option value="font-lora">Lora Serif</option>
                        <option value="font-mono-custom">Roboto Mono</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-600 mb-2">Body Font</label>
                      <select 
                        value={customStyle.fontBody}
                        onChange={(e) => setCustomStyle({...customStyle, fontBody: e.target.value})}
                        className="w-full text-sm border-slate-200 rounded-lg p-2 bg-slate-50 focus:ring-2 focus:ring-blue-500 focus:outline-none"
                      >
                        <option value="font-sans">Inter Sans</option>
                        <option value="font-serif">Merriweather</option>
                        <option value="font-lora">Lora Serif</option>
                      </select>
                    </div>
                  </div>

                  <div>
                     <label className="block text-xs font-semibold text-slate-600 mb-2">Page Density</label>
                     <div className="flex bg-slate-100 p-1 rounded-lg">
                       {['compact', 'comfortable', 'spacious'].map((d) => (
                         <button
                           key={d}
                           onClick={() => setCustomStyle({...customStyle, density: d as any})}
                           className={`flex-1 py-1.5 text-xs font-medium rounded-md capitalize transition-all ${customStyle.density === d ? 'bg-white shadow-sm text-blue-700' : 'text-slate-500 hover:text-slate-700'}`}
                         >
                           {d}
                         </button>
                       ))}
                     </div>
                  </div>
                </div>
              </div>
            )}

            {isAutoStyle && (
              <div className="flex flex-col items-center justify-center h-48 text-center px-6 border-2 border-dashed border-slate-100 rounded-xl bg-slate-50/50">
                 <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mb-3">
                   <Sparkles className="w-6 h-6 text-blue-500" />
                 </div>
                 <p className="text-sm font-medium text-slate-600">
                   Our AI will analyze your content tone ({tone}) and apply the perfect typography and layout automatically.
                 </p>
              </div>
            )}
          </div>
        </div>
      </div>

      <div className="mt-8">
        <button 
          onClick={handleGenerateClick}
          disabled={outline.length === 0}
          className={`
            w-full py-5 font-bold text-lg rounded-2xl shadow-xl transition-all flex items-center justify-center gap-3
            ${outline.length === 0 
              ? 'bg-slate-200 text-slate-400 cursor-not-allowed' 
              : 'bg-black hover:bg-slate-800 text-white hover:shadow-2xl hover:-translate-y-1'}
          `}
        >
          <Play className="w-6 h-6 fill-current" /> 
          {outline.length === 0 ? "Generate Outline First" : "Start Writing Book"}
        </button>
      </div>
    </div>
  );
};