import React, { useState } from 'react';
import { Bot, PenTool, ArrowRight, Mail, KeyRound, User, CheckCircle2, Clock, AlertCircle, Loader2 } from 'lucide-react';
import { supabase, isSupabaseConfigured } from '../services/supabaseClient';

interface Props {
  onLogin: () => void;
}

type ViewState = 'LOGIN' | 'REGISTER' | 'SUCCESS';

export const LoginPage: React.FC<Props> = ({ onLogin }) => {
  const [view, setView] = useState<ViewState>('LOGIN');
  const [isLoading, setIsLoading] = useState(false);
  
  // Form State
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const toggleView = () => {
    setView(view === 'LOGIN' ? 'REGISTER' : 'LOGIN');
    setError('');
    if (view === 'REGISTER') setFullName('');
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);

    try {
      if (isSupabaseConfigured()) {
        // --- SUPABASE FLOW ---
        const { data, error: signUpError } = await supabase!.auth.signUp({
          email,
          password,
          options: {
            data: { full_name: fullName } // Store full name in metadata
          }
        });

        if (signUpError) throw signUpError;
        
        // Note: The Trigger we created in SQL will handle the `profiles` table insertion 
        // and set is_active = false.
        setView('SUCCESS');

      } else {
        // --- DEMO FLOW (LocalStorage) ---
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        const existingUser = localStorage.getItem(`user_${email}`);
        if (existingUser) {
          throw new Error("This email is already registered.");
        }

        const newUser = {
          email,
          password,
          fullName,
          isActive: false, 
          createdAt: new Date().toISOString()
        };
        localStorage.setItem(`user_${email}`, JSON.stringify(newUser));
        setView('SUCCESS');
      }
    } catch (err: any) {
      setError(err.message || "Failed to register.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);

    try {
       // Demo Backdoor
       if (email === 'demo@bookgen.ai' && password === 'demo') {
        onLogin();
        return;
      }

      if (isSupabaseConfigured()) {
        // --- SUPABASE FLOW ---
        const { data: authData, error: authError } = await supabase!.auth.signInWithPassword({
          email,
          password
        });

        if (authError) throw authError;

        if (authData.user) {
          // Check Activation Status from 'profiles' table
          const { data: profile, error: profileError } = await supabase!
            .from('profiles')
            .select('is_active')
            .eq('id', authData.user.id)
            .single();

          if (profileError) {
             console.error(profileError);
             throw new Error("Could not verify account status.");
          }

          if (!profile?.is_active) {
            await supabase!.auth.signOut(); // Log them out immediately
            throw new Error("Account pending activation. Please wait for admin approval.");
          }

          // Success
          onLogin();
        }

      } else {
        // --- DEMO FLOW (LocalStorage) ---
        await new Promise(resolve => setTimeout(resolve, 800));

        const userRecord = localStorage.getItem(`user_${email}`);
        if (!userRecord) throw new Error('No account found with this email.');

        const user = JSON.parse(userRecord);
        if (user.password !== password) throw new Error('Incorrect password.');
        if (!user.isActive) throw new Error('Account pending activation. Please wait for admin approval.');

        onLogin();
      }
    } catch (err: any) {
      setError(err.message || "Failed to sign in.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 flex items-center justify-center p-4 relative overflow-hidden font-sans">
      
      {/* Background Ambience */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-[-10%] left-[-10%] w-[50%] h-[50%] bg-blue-900/20 rounded-full blur-[120px]"></div>
        <div className="absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] bg-violet-900/20 rounded-full blur-[120px]"></div>
      </div>

      <div className="w-full max-w-[420px] relative z-10 animate-fade-in">
        
        {/* Card Container */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-8 shadow-2xl shadow-black/50">
            
            {/* SUCCESS VIEW */}
            {view === 'SUCCESS' && (
              <div className="text-center py-4">
                <div className="w-16 h-16 bg-green-500/10 rounded-full flex items-center justify-center mx-auto mb-6 border border-green-500/20">
                  <CheckCircle2 className="w-8 h-8 text-green-500" />
                </div>
                
                <h2 className="text-2xl font-bold text-white mb-2">Request Received</h2>
                <p className="text-slate-400 text-sm mb-8 leading-relaxed">
                  Thank you for signing up! Your account is currently under review.
                </p>

                <div className="bg-slate-800/50 border border-slate-700 rounded-xl p-4 text-left flex gap-4 mb-8">
                  <Clock className="w-5 h-5 text-blue-400 flex-shrink-0 mt-0.5" />
                  <div>
                    <h4 className="text-white text-sm font-semibold mb-1">Activation pending</h4>
                    <p className="text-slate-400 text-xs leading-relaxed">
                      We usually activate accounts within 1 hour. You will receive an email confirmation once your workspace is ready.
                    </p>
                  </div>
                </div>

                <button 
                  onClick={() => setView('LOGIN')}
                  className="w-full py-3 bg-slate-800 hover:bg-slate-700 text-white font-medium rounded-xl transition-colors border border-slate-700"
                >
                  Back to Sign In
                </button>
              </div>
            )}

            {/* LOGIN / REGISTER VIEW */}
            {view !== 'SUCCESS' && (
              <>
                {/* Logo Area */}
                <div className="flex flex-col items-center mb-8">
                   <div className="relative w-14 h-14 bg-black rounded-2xl flex items-center justify-center shadow-xl shadow-blue-900/30 mb-4 border border-slate-800">
                      <Bot className="w-8 h-8 text-white" strokeWidth={1.5} />
                      <div className="absolute -right-2 -bottom-2 bg-blue-600 rounded-full p-1.5 border-4 border-slate-900">
                        <PenTool className="w-3 h-3 text-white" />
                      </div>
                   </div>

                   <h1 className="text-2xl font-bold text-white">
                     {view === 'LOGIN' ? 'Welcome Back' : 'Request Access'}
                   </h1>
                   <p className="text-slate-400 text-sm mt-2 text-center">
                     {view === 'LOGIN' 
                       ? 'Enter your credentials to access your workspace.' 
                       : 'Join the waitlist to get your private workspace.'}
                   </p>
                </div>

                <form onSubmit={view === 'LOGIN' ? handleLogin : handleRegister} className="space-y-4">
                  
                  {view === 'REGISTER' && (
                    <div className="space-y-1.5 animate-fade-in">
                      <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest ml-1">Full Name</label>
                      <div className="relative group">
                        <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-500 group-focus-within:text-blue-500 transition-colors">
                          <User className="w-4 h-4" />
                        </div>
                        <input 
                          type="text" 
                          required
                          value={fullName}
                          onChange={(e) => setFullName(e.target.value)}
                          placeholder="John Doe"
                          className="w-full pl-10 pr-4 py-3 bg-slate-950/50 border border-slate-700/50 rounded-lg focus:bg-slate-950 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 outline-none transition-all text-white placeholder:text-slate-600 text-sm font-medium"
                        />
                      </div>
                    </div>
                  )}

                  <div className="space-y-1.5">
                    <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest ml-1">Email Address</label>
                    <div className="relative group">
                      <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-500 group-focus-within:text-blue-500 transition-colors">
                        <Mail className="w-4 h-4" />
                      </div>
                      <input 
                        type="email" 
                        required
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        placeholder="name@company.com"
                        className="w-full pl-10 pr-4 py-3 bg-slate-950/50 border border-slate-700/50 rounded-lg focus:bg-slate-950 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 outline-none transition-all text-white placeholder:text-slate-600 text-sm font-medium"
                      />
                    </div>
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest ml-1">Password</label>
                    <div className="relative group">
                      <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-500 group-focus-within:text-blue-500 transition-colors">
                        <KeyRound className="w-4 h-4" />
                      </div>
                      <input 
                        type="password" 
                        required
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        placeholder="••••••••••••"
                        className="w-full pl-10 pr-4 py-3 bg-slate-950/50 border border-slate-700/50 rounded-lg focus:bg-slate-950 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 outline-none transition-all text-white placeholder:text-slate-600 text-sm font-medium"
                      />
                    </div>
                  </div>

                  {error && (
                    <div className="p-3 rounded-lg bg-red-500/10 border border-red-500/20 text-red-400 text-xs font-medium flex items-center gap-2 animate-fade-in">
                      <AlertCircle className="w-4 h-4 flex-shrink-0" />
                      {error}
                    </div>
                  )}

                  <button 
                    type="submit" 
                    disabled={isLoading}
                    className={`
                      w-full py-3 bg-gradient-to-r from-blue-600 to-violet-600 hover:from-blue-500 hover:to-violet-500 text-white font-bold text-sm rounded-lg shadow-lg shadow-blue-900/20 transition-all transform active:scale-[0.98] flex items-center justify-center gap-2 mt-4
                      ${isLoading ? 'opacity-80 cursor-not-allowed' : ''}
                    `}
                  >
                    {isLoading ? (
                      <Loader2 className="w-5 h-5 animate-spin" />
                    ) : (
                      <>
                        {view === 'LOGIN' ? 'Sign In' : 'Request Invite'} 
                        <ArrowRight className="w-4 h-4" />
                      </>
                    )}
                  </button>
                </form>

                <div className="mt-8 text-center border-t border-slate-800 pt-6">
                  <p className="text-xs text-slate-500 mb-2">
                    {view === 'LOGIN' ? "Join the invite list?" : "Already have access?"}
                  </p>
                  <button 
                    onClick={toggleView}
                    className="text-sm font-semibold text-blue-400 hover:text-blue-300 transition-colors"
                  >
                     {view === 'LOGIN' ? 'Request access' : 'Sign in'}
                  </button>
                </div>
              </>
            )}

        </div>
      </div>
    </div>
  );
};