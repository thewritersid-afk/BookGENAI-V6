import React, { useState } from 'react';
import { BookConcept, ResearchSummary } from '../types';
import { CheckCircle2, Lightbulb, UserCheck, Key, ArrowRight, FileText, BarChart3, MessageSquareQuote, Layers, Check, Globe, Link } from 'lucide-react';

interface Props {
  summary: ResearchSummary;
  concepts: BookConcept[];
  onSelect: (concept: BookConcept, selectedTopics: string[]) => void;
}

export const ConceptSelection: React.FC<Props> = ({ summary, concepts, onSelect }) => {
  const [selectedTopics, setSelectedTopics] = useState<string[]>([]);

  const toggleTopic = (topic: string) => {
    if (selectedTopics.includes(topic)) {
      setSelectedTopics(selectedTopics.filter(t => t !== topic));
    } else {
      setSelectedTopics([...selectedTopics, topic]);
    }
  };

  return (
    <div className="max-w-6xl mx-auto p-6 space-y-10 animate-fade-in pb-20">
      
      <div className="text-center">
         <h2 className="text-3xl font-bold text-slate-900">Research Dossier</h2>
         <p className="text-slate-500">Analysis complete. Review insights and select your book's direction.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Column 1: Core Analysis */}
        <div className="bg-white rounded-3xl p-6 shadow-xl border border-slate-100 flex flex-col lg:col-span-2">
            <h3 className="text-lg font-bold text-slate-900 mb-4 flex items-center gap-2">
                <FileText className="w-5 h-5 text-blue-600" /> Content Analysis
            </h3>
            <div className="bg-slate-50 p-4 rounded-xl border-l-4 border-blue-500 mb-6">
                 <p className="text-slate-700 leading-relaxed text-sm">
                  {summary.contentOverview}
                 </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-auto">
                <div>
                   <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-3 flex items-center gap-2">
                       <MessageSquareQuote className="w-4 h-4" /> Central Arguments
                   </h4>
                   <ul className="space-y-2">
                       {summary.centralArguments?.map((arg, i) => (
                           <li key={i} className="text-sm text-slate-700 flex items-start gap-2">
                               <div className="w-1.5 h-1.5 rounded-full bg-blue-400 mt-1.5 flex-shrink-0" />
                               {arg}
                           </li>
                       ))}
                   </ul>
                </div>
                <div>
                    <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-3 flex items-center gap-2">
                       <BarChart3 className="w-4 h-4" /> Sentiment & Themes
                   </h4>
                   <div className="mb-4">
                       <span className="inline-block px-3 py-1 bg-green-100 text-green-800 rounded-full text-xs font-bold mb-2">
                           {summary.sentiment || "Analytical"}
                       </span>
                   </div>
                   <div className="flex flex-wrap gap-2">
                      {summary.keyTopics?.map((topic, i) => (
                        <span key={i} className="px-2 py-1 bg-slate-100 text-slate-600 rounded text-xs font-medium border border-slate-200">
                          {topic}
                        </span>
                      ))}
                    </div>
                </div>
            </div>

            {/* Sources Section */}
            {summary.sources && summary.sources.length > 0 && (
              <div className="mt-6 pt-4 border-t border-slate-200">
                  <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-3 flex items-center gap-2">
                     <Globe className="w-4 h-4" /> Research Sources
                  </h4>
                  <div className="flex flex-wrap gap-2">
                    {summary.sources.map((source, i) => {
                      let hostname = source;
                      try {
                        hostname = new URL(source).hostname.replace('www.', '');
                      } catch (e) {}
                      
                      return (
                        <a 
                          key={i} 
                          href={source} 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="flex items-center gap-1.5 px-3 py-1.5 bg-blue-50 hover:bg-blue-100 text-blue-700 rounded-full text-xs font-medium transition-colors border border-blue-100"
                        >
                          <Link className="w-3 h-3" />
                          {hostname}
                        </a>
                      );
                    })}
                  </div>
              </div>
            )}
        </div>

        {/* Column 2: Deep Dive Selection */}
        <div className="bg-gradient-to-b from-slate-900 to-slate-800 text-white rounded-3xl p-6 shadow-xl flex flex-col">
            <h3 className="text-lg font-bold text-white mb-2 flex items-center gap-2">
                <Layers className="w-5 h-5 text-purple-400" /> Deep Dive Opportunities
            </h3>
            <p className="text-xs text-slate-400 mb-6">Select related topics to expand your book's scope.</p>
            
            <div className="space-y-3 flex-grow">
                {summary.suggestedDeepDiveTopics?.map((topic, i) => {
                    const isSelected = selectedTopics.includes(topic);
                    return (
                        <button 
                            key={i}
                            onClick={() => toggleTopic(topic)}
                            className={`w-full text-left p-3 rounded-xl border transition-all flex items-center justify-between group
                                ${isSelected 
                                    ? 'bg-blue-600 border-blue-500 text-white shadow-lg shadow-blue-900/50' 
                                    : 'bg-white/5 border-white/10 text-slate-300 hover:bg-white/10'}`}
                        >
                            <span className="text-sm font-medium pr-2">{topic}</span>
                            <div className={`w-5 h-5 rounded-full border flex items-center justify-center transition-colors
                                ${isSelected ? 'bg-white border-white text-blue-600' : 'border-slate-500 group-hover:border-slate-300'}`}>
                                {isSelected && <Check className="w-3 h-3" strokeWidth={4} />}
                            </div>
                        </button>
                    )
                })}
            </div>
            
            <div className="mt-6 pt-6 border-t border-white/10 text-center">
                <span className="text-xs font-bold text-blue-300 uppercase tracking-wider">
                    {selectedTopics.length} Topics Selected
                </span>
            </div>
        </div>
      </div>

      <div className="text-center space-y-2 pt-8">
        <h2 className="text-3xl font-bold text-gray-800">Select Your Book Concept</h2>
        <p className="text-gray-600">Choose a path below. We will incorporate your selected deep dive topics.</p>
      </div>

      {/* Concepts Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {concepts.map((concept) => (
          <div 
            key={concept.id}
            className="group relative bg-white rounded-2xl p-6 shadow-lg border border-gray-100 hover:shadow-2xl hover:border-blue-500 transition-all duration-300 flex flex-col cursor-pointer"
            onClick={() => onSelect(concept, selectedTopics)}
          >
            <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-blue-500 to-indigo-500 rounded-t-2xl opacity-0 group-hover:opacity-100 transition-opacity" />
            
            <div className="mb-4">
              <h3 className="text-xl font-bold text-gray-900 leading-tight mb-2 group-hover:text-blue-600 transition-colors">
                {concept.title}
              </h3>
              <p className="text-sm font-medium text-gray-500 italic mb-4">
                {concept.subtitle}
              </p>
            </div>

            <p className="text-gray-600 text-sm flex-grow mb-6 leading-relaxed">
              {concept.description}
            </p>

            <div className="space-y-3 pt-6 border-t border-gray-100">
              <div className="flex items-center gap-2 text-xs text-gray-500">
                <UserCheck className="w-4 h-4 text-blue-500" />
                <span className="font-semibold">Target:</span> {concept.targetAudience}
              </div>
              <div className="flex items-center gap-2 text-xs text-gray-500">
                <Key className="w-4 h-4 text-orange-500" />
                <span className="font-semibold">Est. Chapters:</span> {concept.estimatedChapters}
              </div>
            </div>

            <button className="mt-6 w-full py-2 bg-gray-50 text-gray-700 font-semibold rounded-lg group-hover:bg-blue-600 group-hover:text-white transition-colors flex items-center justify-center gap-2">
              Generate This Book <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};