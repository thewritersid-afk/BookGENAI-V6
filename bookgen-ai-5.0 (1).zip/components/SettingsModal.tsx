import React, { useState, useEffect } from 'react';
import { X, Key, Save, Loader2, ShieldCheck, ExternalLink, AlertTriangle } from 'lucide-react';
import { supabase } from '../services/supabaseClient';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  currentKey: string;
  onSave: (key: string) => void;
}

export const SettingsModal: React.FC<Props> = ({ isOpen, onClose, currentKey, onSave }) => {
  const [apiKey, setApiKey] = useState(currentKey);
  const [isSaving, setIsSaving] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);
  const [savedLocally, setSavedLocally] = useState(false);

  useEffect(() => {
    setApiKey(currentKey);
  }, [currentKey, isOpen]);

  if (!isOpen) return null;

  const handleSave = async () => {
    if (!apiKey.trim()) {
      setError("API Key cannot be empty.");
      return;
    }
    
    setIsSaving(true);
    setError('');
    setSuccess(false);
    setSavedLocally(false);

    try {
      const { data: { user } } = await supabase.auth.getUser();
      
      let savedToDb = false;

      if (user) {
        // Attempt to update Supabase Profile
        try {
          const { error: updateError } = await supabase
            .from('profiles')
            .update({ google_api_key: apiKey.trim() })
            .eq('id', user.id);

          if (updateError) {
            // Check if it's the specific "column does not exist" error
            // PostgREST error code 42703 is undefined_column, but Supabase JS returns it in the message often
            if (updateError.message?.includes('column') || updateError.code === '42703' || updateError.message?.includes('schema')) {
               console.warn("Database column missing. Falling back to local storage.");
               // We don't throw, we just proceed to local save
            } else {
               throw updateError;
            }
          } else {
            savedToDb = true;
          }
        } catch (dbErr) {
           console.warn("Database save failed, using local storage fallback.");
           // Fallback to local
        }
      }

      // Always save to local storage as backup/primary if DB fails
      localStorage.setItem('bookgen_api_key', apiKey.trim());
      
      if (!savedToDb) {
        setSavedLocally(true);
      }

      onSave(apiKey.trim());
      setSuccess(true);
      
      setTimeout(() => {
        setSuccess(false);
        setSavedLocally(false);
        onClose();
      }, 1500);

    } catch (err: any) {
      setError(err.message || "Failed to save API key.");
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-fade-in">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md overflow-hidden border border-slate-200">
        <div className="bg-slate-50 px-6 py-4 border-b border-slate-100 flex justify-between items-center">
          <h3 className="font-bold text-slate-800 flex items-center gap-2">
            <Key className="w-4 h-4 text-blue-600" /> API Configuration
          </h3>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600 transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>
        
        <div className="p-6 space-y-4">
          <div className="bg-blue-50 border border-blue-100 rounded-lg p-4 flex gap-3">
             <ShieldCheck className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
             <div className="text-sm text-blue-800">
               <p className="font-semibold mb-1">Bring Your Own Key</p>
               <p className="opacity-80 leading-relaxed">
                 BookGen AI uses your personal Gemini API key. It is stored securely in your database profile and used only for your requests.
               </p>
             </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-500 uppercase tracking-widest mb-2">
              Gemini API Key
            </label>
            <input 
              type="password" 
              value={apiKey}
              onChange={(e) => setApiKey(e.target.value)}
              placeholder="AIzaSy..."
              className="w-full p-3 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all font-mono text-sm"
            />
            <a 
              href="https://aistudio.google.com/app/apikey" 
              target="_blank" 
              rel="noreferrer"
              className="inline-flex items-center gap-1 text-xs text-blue-600 font-semibold mt-2 hover:underline"
            >
              Get a key from Google AI Studio <ExternalLink className="w-3 h-3" />
            </a>
          </div>

          {error && (
            <div className="text-xs text-red-500 font-medium p-2 bg-red-50 rounded border border-red-100">
              {error}
            </div>
          )}
          
          {success && savedLocally && (
             <div className="text-xs text-orange-600 font-medium p-2 bg-orange-50 rounded border border-orange-100 flex items-center gap-2">
               <AlertTriangle className="w-3 h-3" />
               Saved to this device (Database column missing)
             </div>
          )}
        </div>

        <div className="p-6 pt-0 flex justify-end">
          <button 
            onClick={handleSave}
            disabled={isSaving}
            className={`
              flex items-center gap-2 px-6 py-2.5 rounded-xl font-bold text-sm transition-all
              ${success 
                ? 'bg-green-500 text-white' 
                : 'bg-slate-900 text-white hover:bg-slate-800'}
            `}
          >
            {isSaving ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : success ? (
              savedLocally ? "Saved Locally" : "Saved!"
            ) : (
              <>
                <Save className="w-4 h-4" /> Save Configuration
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};