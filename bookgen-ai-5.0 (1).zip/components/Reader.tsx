import React, { useRef, useState, useEffect } from 'react';
import { GeneratedBook } from '../types';
import { Download, FileText, ChevronLeft, Printer, Loader2, Palette } from 'lucide-react';
import ReactMarkdown from 'react-markdown';

interface Props {
  book: GeneratedBook;
  onReset: () => void;
}

export const Reader: React.FC<Props> = ({ book, onReset }) => {
  const bookRef = useRef<HTMLDivElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);
  const [isDownloading, setIsDownloading] = useState(false);
  const [scale, setScale] = useState(1);

  // Responsive Scaling Logic
  useEffect(() => {
    const handleResize = () => {
      // The book container is fixed at 576px width (6 inches @ 96dpi)
      // plus some visual margin we want to preserve on mobile.
      const bookWidth = 576; 
      const screenPadding = 32; // 16px padding on each side
      const availableWidth = window.innerWidth - screenPadding;
      
      if (availableWidth < bookWidth) {
        setScale(availableWidth / bookWidth);
      } else {
        setScale(1);
      }
    };

    window.addEventListener('resize', handleResize);
    handleResize(); // Initial calculation
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // KDP 6x9 Standard Settings
  const fontBodyClass = "font-garamond text-slate-900"; 
  const fontHeaderClass = "font-garamond text-slate-900"; 

  // Custom Markdown Components for KDP Styling
  const MarkdownComponents = {
    h1: ({node, ...props}: any) => <h1 className={`block clear-both text-2xl font-bold mt-8 mb-4 leading-tight border-b-2 border-slate-200 pb-2 ${fontHeaderClass}`} {...props} />,
    h2: ({node, ...props}: any) => <h2 className={`block clear-both text-xl font-bold mt-6 mb-3 leading-tight ${fontHeaderClass}`} {...props} />,
    h3: ({node, ...props}: any) => <h3 className={`block clear-both text-lg font-bold mt-4 mb-2 leading-snug ${fontHeaderClass}`} {...props} />,
    p: ({node, ...props}: any) => <p className={`block text-[11pt] leading-[1.4] text-justify mb-0 ${fontBodyClass}`} {...props} />,
    ul: ({node, ...props}: any) => <ul className={`list-disc pl-8 mb-4 space-y-1 text-[11pt] text-justify ${fontBodyClass}`} {...props} />,
    ol: ({node, ...props}: any) => <ol className={`list-decimal pl-8 mb-4 space-y-1 text-[11pt] text-justify ${fontBodyClass}`} {...props} />,
    li: ({node, ...props}: any) => <li className="pl-1" {...props} />,
    strong: ({node, ...props}: any) => <strong className="font-bold text-black" {...props} />,
    blockquote: ({node, ...props}: any) => <blockquote className={`border-l-2 border-slate-400 pl-4 italic my-4 ml-4 ${fontBodyClass}`} {...props} />,
  };

  const downloadDoc = () => {
    const header = "<html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:word' xmlns='http://www.w3.org/TR/REC-html40'><head><meta charset='utf-8'><title>" + book.title + "</title></head><body>";
    const footer = "</body></html>";
    const sourceHTML = header + bookRef.current?.innerHTML + footer;
    
    const source = 'data:application/vnd.ms-word;charset=utf-8,' + encodeURIComponent(sourceHTML);
    const fileDownload = document.createElement("a");
    document.body.appendChild(fileDownload);
    fileDownload.href = source;
    fileDownload.download = `${book.title.replace(/ /g, '_')}.doc`;
    fileDownload.click();
    document.body.removeChild(fileDownload);
  };

  const downloadPDF = async () => {
    if (!contentRef.current || !window.jspdf) return;
    
    setIsDownloading(true);
    try {
      const { jsPDF } = window.jspdf;
      
      const pdf = new jsPDF({
        orientation: 'p',
        unit: 'pt',
        format: [432, 648] 
      });

      const pdfContentWidth = 324;
      const htmlWindowWidth = 432;

      await pdf.html(contentRef.current, {
        callback: function (doc: any) {
          doc.save(`${book.title.replace(/ /g, '_')}_6x9_KDP.pdf`);
          setIsDownloading(false);
        },
        margin: [54, 45, 54, 63],
        width: pdfContentWidth,
        windowWidth: htmlWindowWidth,
        autoPaging: 'text',
        html2canvas: {
          scale: 0.75,
          useCORS: true,
          letterRendering: true,
          logging: false
        }
      });
    } catch (error) {
      console.error("PDF generation failed", error);
      setIsDownloading(false);
      alert("Could not generate PDF directly. Please try 'Print to PDF' instead.");
    }
  };

  const printBook = () => {
     window.print();
  };

  return (
    <div className="min-h-screen bg-gray-100 p-4 md:p-8">
      {/* Control Bar - Responsive Layout */}
      <div className="fixed top-0 left-0 w-full bg-white shadow-md z-50 px-4 md:px-6 py-3 md:py-4 flex flex-wrap gap-2 justify-between items-center no-print border-b border-gray-200">
        <button 
          onClick={onReset}
          className="flex items-center gap-2 text-gray-600 hover:text-blue-600 font-medium transition-colors text-sm md:text-base"
        >
          <ChevronLeft className="w-4 h-4 md:w-5 md:h-5" /> <span className="hidden sm:inline">Back</span>
        </button>
        
        <div className="flex items-center gap-2 md:gap-4 overflow-x-auto no-scrollbar">
           <div className="hidden xl:flex items-center gap-2 text-xs font-semibold text-slate-500 bg-slate-50 px-3 py-1.5 rounded-full border border-slate-200 whitespace-nowrap">
             <Palette className="w-3 h-3" />
             Format: 6" x 9" KDP Trade Paperback
           </div>

           <div className="h-6 w-px bg-slate-200 hidden xl:block"></div>

          <button 
            onClick={printBook}
            className="hidden md:flex items-center gap-2 px-3 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-lg transition-colors font-medium text-sm whitespace-nowrap"
          >
            <Printer className="w-4 h-4" /> <span className="hidden lg:inline">Print</span>
          </button>

          <button 
            onClick={downloadPDF}
            disabled={isDownloading}
            className="flex items-center gap-2 px-3 py-2 bg-slate-800 hover:bg-slate-900 text-white rounded-lg transition-colors font-medium disabled:opacity-50 text-sm whitespace-nowrap"
          >
            {isDownloading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Download className="w-4 h-4" />}
            {isDownloading ? '...' : <span className="hidden sm:inline">PDF</span>}
            <span className="sm:hidden">PDF</span>
          </button>

          <button 
            onClick={downloadDoc}
            className="flex items-center gap-2 px-3 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg shadow-md transition-colors font-medium text-sm whitespace-nowrap"
          >
            <FileText className="w-4 h-4" /> <span className="hidden sm:inline">DOCX</span>
          </button>
        </div>
      </div>

      {/* Book Container - Visual Preview */}
      <div className="mt-16 md:mt-20 flex justify-center pb-20 overflow-hidden">
        {/* 
            Wrapper for scaling.
            We use CSS transform to scale the book down on mobile devices 
            while preserving its internal layout dimensions for the PDF generator.
        */}
        <div style={{ 
          transform: `scale(${scale})`, 
          transformOrigin: 'top center',
          width: '576px', // Fixed Layout Width
          height: scale < 1 ? 'auto' : undefined // Allow height to flow
        }}>
          <div 
            id="book-preview-container" 
            ref={bookRef}
            className="bg-white shadow-2xl min-h-[900px] w-[576px] pl-[84px] pr-[60px] py-[72px] text-gray-900"
          >
            {/* Inner Content Wrapper - Capture THIS for PDF to avoid double margins */}
            <div ref={contentRef} className={`kdp-body w-full ${fontBodyClass}`}>
              
              {/* Title Page */}
              <div className="min-h-[600px] flex flex-col justify-center items-center text-center page-break mb-12 border-b border-gray-100 pb-12">
                <h1 className={`text-4xl font-bold mb-4 tracking-tight text-gray-900 leading-tight ${fontHeaderClass}`}>{book.title}</h1>
                <h2 className={`text-xl font-normal text-gray-600 italic mb-16 leading-normal ${fontHeaderClass}`}>{book.subtitle}</h2>
                
                <div className="mt-auto">
                  <p className={`text-xs text-gray-400 uppercase tracking-widest mb-2 font-sans`}>Written By</p>
                  <p className={`text-lg font-bold ${fontBodyClass}`}>{book.author}</p>
                </div>
              </div>

              {/* Copyright Page */}
              <div className="page-break flex flex-col justify-end h-[600px] mb-12 text-xs text-gray-500 text-left">
                <p className="mb-4">Copyright © {new Date().getFullYear()} {book.author}</p>
                <p className="mb-4">All rights reserved. No part of this book may be reproduced in any form without permission in writing from the publisher, except in the case of brief quotations embodied in critical articles or reviews.</p>
                <p>Generated by BookGen AI.</p>
              </div>

              {/* Table of Contents */}
              <div className="page-break mb-12">
                <h2 className={`text-2xl font-bold mb-8 text-center ${fontHeaderClass}`}>Table of Contents</h2>
                <div className="space-y-4">
                  <div className="flex justify-between border-b border-dotted border-gray-300 pb-1">
                    <span className={`text-base font-medium ${fontBodyClass}`}>Introduction</span>
                  </div>
                  {book.chapters.map((chapter) => (
                    <div key={chapter.number} className="flex justify-between border-b border-dotted border-gray-300 pb-1">
                      <span className={`text-base ${fontBodyClass}`}>Chapter {chapter.number}: {chapter.title}</span>
                    </div>
                  ))}
                  <div className="flex justify-between border-b border-dotted border-gray-300 pb-1">
                    <span className={`text-base font-medium ${fontBodyClass}`}>Conclusion</span>
                  </div>
                  {book.authorBio && (
                    <div className="flex justify-between border-b border-dotted border-gray-300 pb-1">
                      <span className={`text-base font-medium ${fontBodyClass}`}>About the Author</span>
                    </div>
                  )}
                </div>
              </div>

              {/* Introduction */}
              <div className="page-break mb-12">
                <h2 className={`text-2xl font-bold mb-6 text-center ${fontHeaderClass}`}>Introduction</h2>
                <div className="prose prose-p:my-0 prose-headings:my-4 max-w-none text-justify">
                  <ReactMarkdown components={MarkdownComponents}>{book.introduction}</ReactMarkdown>
                </div>
              </div>

              {/* Chapters */}
              {book.chapters.map((chapter) => (
                <div key={chapter.number} className="page-break mb-12">
                  <div className="mb-8 pt-8">
                    <p className="text-center text-sm font-bold uppercase tracking-widest text-gray-400 mb-2">Chapter {chapter.number}</p>
                    <h2 className={`text-3xl font-bold text-center text-gray-900 leading-tight ${fontHeaderClass}`}>{chapter.title}</h2>
                  </div>
                  <div className="prose prose-p:my-0 prose-headings:my-4 max-w-none text-justify">
                    <ReactMarkdown components={MarkdownComponents}>{chapter.content}</ReactMarkdown>
                  </div>
                </div>
              ))}

              {/* Conclusion */}
              <div className="page-break mb-12">
                <h2 className={`text-2xl font-bold mb-6 text-center ${fontHeaderClass}`}>Conclusion</h2>
                <div className="prose prose-p:my-0 prose-headings:my-4 max-w-none text-justify">
                  <ReactMarkdown components={MarkdownComponents}>{book.conclusion}</ReactMarkdown>
                </div>
              </div>

              {/* About the Author (Conditional) */}
              {book.authorBio && (
                <div className="page-break">
                  <h2 className={`text-2xl font-bold mb-6 text-center ${fontHeaderClass}`}>About the Author</h2>
                  <div className="bg-gray-50 p-8 border border-gray-100">
                    <div className="flex flex-col items-center text-center">
                        <div className="w-20 h-20 bg-gray-200 rounded-full flex items-center justify-center text-2xl font-bold text-gray-500 font-serif mb-4">
                          {book.author.charAt(0)}
                        </div>
                        <h3 className={`text-xl font-bold mb-2 ${fontHeaderClass}`}>{book.author}</h3>
                        <p className={`text-base leading-relaxed ${fontBodyClass}`}>{book.authorBio}</p>
                    </div>
                  </div>
                </div>
              )}

            </div>
          </div>
        </div>
      </div>
    </div>
  );
};