import React, { useState, useRef } from 'react';
import { Upload, FileText, Bot, PenTool, Sparkles, ArrowRight, BrainCircuit, Library, X } from 'lucide-react';
import { UploadedFile } from '../types';

interface Props {
  onAnalyze: (text: string, files: UploadedFile[]) => void;
  isAnalyzing: boolean;
}

type Tab = 'files' | 'text';

export const IngestionStep: React.FC<Props> = ({ onAnalyze, isAnalyzing }) => {
  const [activeTab, setActiveTab] = useState<Tab>('files');
  const [textInput, setTextInput] = useState('');
  const [files, setFiles] = useState<UploadedFile[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isDragOver, setIsDragOver] = useState(false);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      processFiles(e.target.files);
    }
  };

  const processFiles = async (fileList: FileList) => {
    const newFiles: UploadedFile[] = [];
    for (let i = 0; i < fileList.length; i++) {
      const file = fileList[i];
      const base64 = await convertToBase64(file);
      newFiles.push({
        name: file.name,
        type: file.type,
        data: base64,
        mimeType: file.type
      });
    }
    setFiles([...files, ...newFiles]);
  };

  const convertToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => {
        const result = reader.result as string;
        const base64 = result.split(',')[1];
        resolve(base64);
      };
      reader.onerror = error => reject(error);
    });
  };

  const removeFile = (index: number) => {
    setFiles(files.filter((_, i) => i !== index));
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    setIsDragOver(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    if (e.dataTransfer.files) {
      processFiles(e.dataTransfer.files);
    }
  };

  const wordCount = textInput.trim().split(/\s+/).length;

  return (
    <div className="min-h-screen bg-white text-slate-900 flex flex-col items-center">
      
      {/* Header Section */}
      <header className="w-full max-w-5xl mx-auto pt-12 md:pt-16 pb-8 md:pb-12 px-4 md:px-6 text-center">
        <div className="flex justify-center items-center gap-3 mb-4 md:mb-6">
          <div className="relative w-12 h-12 md:w-14 md:h-14 bg-black rounded-2xl flex items-center justify-center shadow-xl">
            <Bot className="w-6 h-6 md:w-8 md:h-8 text-white" strokeWidth={1.5} />
            <div className="absolute -right-2 -bottom-2 bg-blue-600 rounded-full p-1.5 border-4 border-white">
              <PenTool className="w-3 h-3 text-white" />
            </div>
          </div>
          <h1 className="text-3xl md:text-4xl font-bold tracking-tight text-black">
            BookGen AI
          </h1>
        </div>
        
        <h2 className="text-xl md:text-3xl font-bold text-slate-900 leading-tight max-w-3xl mx-auto mb-3 md:mb-4">
          Turn anything — anyone’s content — into your own best-selling book.
        </h2>
        <p className="text-slate-500 font-medium text-base md:text-lg">
          Professional. Intelligent. Automated.
        </p>
      </header>

      {/* Main Input Card */}
      <div className="w-full max-w-4xl px-4 md:px-6">
        <div className="bg-white border border-slate-200 shadow-2xl shadow-slate-200/50 rounded-3xl overflow-hidden relative">
          
          {/* Tabs */}
          <div className="flex border-b border-slate-100">
            <button
              onClick={() => setActiveTab('files')}
              className={`flex-1 py-4 md:py-5 text-xs md:text-sm font-bold uppercase tracking-wider flex items-center justify-center gap-2 transition-all
                ${activeTab === 'files' 
                  ? 'bg-blue-600 text-white shadow-inner' 
                  : 'bg-slate-50 text-slate-500 hover:bg-slate-100'}`}
            >
              <Upload className="w-4 h-4" /> File Upload
            </button>
            <button
              onClick={() => setActiveTab('text')}
              className={`flex-1 py-4 md:py-5 text-xs md:text-sm font-bold uppercase tracking-wider flex items-center justify-center gap-2 transition-all
                ${activeTab === 'text' 
                  ? 'bg-blue-600 text-white shadow-inner' 
                  : 'bg-slate-50 text-slate-500 hover:bg-slate-100'}`}
            >
              <FileText className="w-4 h-4" /> Text Input
            </button>
          </div>

          <div className="p-6 md:p-12 min-h-[350px] md:min-h-[400px] flex flex-col">
            
            {/* FILE UPLOAD CONTENT */}
            {activeTab === 'files' && (
              <div className="animate-fade-in flex-grow flex flex-col">
                <div 
                  onDragOver={handleDragOver}
                  onDragLeave={handleDragLeave}
                  onDrop={handleDrop}
                  onClick={() => fileInputRef.current?.click()}
                  className={`flex-grow border-2 border-dashed rounded-2xl flex flex-col items-center justify-center p-6 md:p-10 cursor-pointer transition-all duration-300 group
                    ${isDragOver 
                      ? 'border-blue-600 bg-blue-50/50 scale-[1.01]' 
                      : 'border-slate-200 hover:border-blue-300 hover:bg-slate-50'}`}
                >
                  <div className={`w-16 h-16 md:w-20 md:h-20 rounded-full flex items-center justify-center mb-4 md:mb-6 transition-all duration-300
                    ${isDragOver ? 'bg-blue-200' : 'bg-slate-100 group-hover:bg-blue-100'}`}>
                    <Upload className={`w-8 h-8 md:w-10 md:h-10 transition-colors ${isDragOver ? 'text-blue-700' : 'text-slate-400 group-hover:text-blue-600'}`} />
                  </div>
                  
                  <h3 className="text-lg md:text-xl font-bold text-slate-900 mb-2 text-center">
                    Click to upload or drag & drop
                  </h3>
                  <p className="text-slate-500 mb-4 md:mb-6 text-center max-w-sm text-sm md:text-base">
                    Support for PDF, TXT, MD, MP3, and WAV. 
                    <br/><span className="text-xs font-semibold text-blue-600 uppercase mt-2 inline-block">Max Size: 30GB</span>
                  </p>
                  
                  <div className="flex flex-wrap gap-2 justify-center">
                    {['PDF', 'TXT', 'MD', 'MP3', 'WAV'].map(ext => (
                      <span key={ext} className="text-[10px] md:text-xs font-bold text-slate-400 bg-slate-100 px-2 py-1 rounded">
                        {ext}
                      </span>
                    ))}
                  </div>

                  <input 
                    type="file" 
                    ref={fileInputRef} 
                    onChange={handleFileChange} 
                    className="hidden" 
                    multiple
                    accept=".pdf,.txt,.md,.mp3,.wav,.docx" 
                  />
                </div>

                {files.length > 0 && (
                  <div className="mt-6 space-y-3">
                    <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest">Attached Files</h4>
                    <div className="grid grid-cols-1 gap-2">
                      {files.map((f, idx) => (
                        <div key={idx} className="flex items-center justify-between p-3 md:p-4 bg-slate-50 rounded-xl border border-slate-100 shadow-sm group hover:border-blue-200 transition-colors">
                          <div className="flex items-center gap-3 overflow-hidden">
                            <div className="w-8 h-8 bg-white rounded-lg flex items-center justify-center border border-slate-100 text-blue-600 flex-shrink-0">
                              <FileText className="w-4 h-4" />
                            </div>
                            <span className="font-medium text-slate-700 truncate text-sm md:text-base">{f.name}</span>
                          </div>
                          <button 
                            onClick={(e) => { e.stopPropagation(); removeFile(idx); }} 
                            className="p-2 text-slate-400 hover:text-red-500 hover:bg-red-50 rounded-full transition-all flex-shrink-0"
                          >
                            <X className="w-4 h-4" />
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* TEXT INPUT CONTENT */}
            {activeTab === 'text' && (
              <div className="animate-fade-in flex-grow flex flex-col h-full">
                <div className="relative flex-grow">
                  <textarea 
                    value={textInput}
                    onChange={(e) => setTextInput(e.target.value)}
                    placeholder="Paste your script, article, or raw notes here..."
                    className="w-full h-full min-h-[300px] p-4 md:p-6 bg-slate-50 rounded-2xl border border-slate-200 focus:border-blue-500 focus:ring-4 focus:ring-blue-500/10 transition-all resize-none text-slate-700 leading-relaxed text-base md:text-lg placeholder:text-slate-400 focus:bg-white"
                  />
                  <div className="absolute bottom-4 right-4 text-xs font-medium text-slate-400 bg-white/80 px-3 py-1 rounded-full border border-slate-100 backdrop-blur-sm">
                    {wordCount.toLocaleString()} / 50,000 words
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Action Bar */}
          <div className="p-6 md:p-8 bg-slate-50 border-t border-slate-100 flex justify-end">
            <button
              onClick={() => onAnalyze(textInput, files)}
              disabled={isAnalyzing || (!textInput && files.length === 0)}
              className={`
                w-full md:w-auto group relative px-8 md:px-10 py-4 md:py-5 rounded-xl font-bold text-lg shadow-xl transition-all duration-300
                ${isAnalyzing || (!textInput && files.length === 0)
                  ? 'bg-slate-200 text-slate-400 cursor-not-allowed shadow-none' 
                  : 'bg-blue-600 text-white hover:bg-blue-700 hover:-translate-y-1 hover:shadow-blue-600/30'}
              `}
            >
              {isAnalyzing ? (
                <div className="flex items-center justify-center gap-3">
                   <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                   <span>Analyzing...</span>
                </div>
              ) : (
                <div className="flex items-center justify-center gap-3">
                  <span>Start Research</span>
                  <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                </div>
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Explanation Section */}
      <div className="mt-16 md:mt-24 mb-16 md:mb-24 w-full max-w-6xl px-6">
        <div className="text-center mb-12 md:mb-16">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-blue-50 text-blue-700 rounded-full text-xs font-bold uppercase tracking-widest mb-4">
            <Sparkles className="w-3 h-3" /> The Process
          </div>
          <h3 className="text-2xl md:text-3xl font-bold text-slate-900">How BookGen AI Works</h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 md:gap-12">
          {/* Step 1 */}
          <div className="flex flex-col items-center text-center group">
            <div className="w-20 h-20 md:w-24 md:h-24 bg-white rounded-3xl border border-slate-100 shadow-xl shadow-slate-200/50 flex items-center justify-center mb-6 md:mb-8 group-hover:-translate-y-2 transition-transform duration-500">
              <Upload className="w-8 h-8 md:w-10 md:h-10 text-blue-600" strokeWidth={1.5} />
            </div>
            <h4 className="text-lg md:text-xl font-bold text-slate-900 mb-2 md:mb-3">1. Upload Content</h4>
            <p className="text-slate-500 leading-relaxed max-w-xs text-sm md:text-base">
              Provide any video file, audio recording, PDF, or text script. We handle heavy files securely.
            </p>
          </div>

          {/* Step 2 */}
          <div className="flex flex-col items-center text-center group">
            <div className="w-20 h-20 md:w-24 md:h-24 bg-blue-600 rounded-3xl shadow-xl shadow-blue-600/30 flex items-center justify-center mb-6 md:mb-8 animate-float z-10">
              <BrainCircuit className="w-8 h-8 md:w-10 md:h-10 text-white" strokeWidth={1.5} />
            </div>
            <h4 className="text-lg md:text-xl font-bold text-slate-900 mb-2 md:mb-3">2. Deep Analysis</h4>
            <p className="text-slate-500 leading-relaxed max-w-xs text-sm md:text-base">
              Our AI acts as an expert researcher, extracting core insights and themes.
            </p>
          </div>

          {/* Step 3 */}
          <div className="flex flex-col items-center text-center group">
            <div className="w-20 h-20 md:w-24 md:h-24 bg-white rounded-3xl border border-slate-100 shadow-xl shadow-slate-200/50 flex items-center justify-center mb-6 md:mb-8 group-hover:-translate-y-2 transition-transform duration-500 delay-100">
              <Library className="w-8 h-8 md:w-10 md:h-10 text-black" strokeWidth={1.5} />
            </div>
            <h4 className="text-lg md:text-xl font-bold text-slate-900 mb-2 md:mb-3">3. Book Generation</h4>
            <p className="text-slate-500 leading-relaxed max-w-xs text-sm md:text-base">
              We structure, write, and format a professional book tailored to your audience.
            </p>
          </div>
        </div>
      </div>
      
      <footer className="w-full border-t border-slate-100 py-6 md:py-8 text-center text-slate-400 text-xs md:text-sm">
        &copy; {new Date().getFullYear()} BookGen AI. All rights reserved.
      </footer>
    </div>
  );
};